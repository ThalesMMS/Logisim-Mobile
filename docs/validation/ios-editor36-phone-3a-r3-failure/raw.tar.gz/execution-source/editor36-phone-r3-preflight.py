"""Read-only pre/post fingerprint check for the single Editor36 R3 lease."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, importlib.util, json, plistlib, re, subprocess, sys
ROOT=Path(__file__).resolve().parents[1]
PRODUCER=Path('/Users/thales/GitHub/logisim-mobile-worktrees/mobile-final-keyboard-ownership-3a0a01f1')
PRODUCTION=PRODUCER/'outputs/mobile-final-keyboard-ownership-3a0a01f1'
MANIFEST=PRODUCTION/'artifact.json'
DEVICE='20A4D87D-A2A6-46BD-A889-C4888CE1E152'
SOURCE='91bc58e38e0171777df5951b018a23ac6da8da69'
PRODUCER_SOURCE='3a0a01f1af05dd3fea75d5a1499c762d039c478a'
MANIFEST_SHA='7e83088f9d1ccee3c268e9dec954db9c351b47db9cd01b9fb652e8f1235b7b76'
BUNDLE='thalesmms.logisim.mobile'
SELECTOR='EditorEndToEndTests/EditorEndToEndTests/testEditingConnectionsHistoryAndViewport'

def run(args):
    return subprocess.check_output(args,text=True).strip()
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def inventory(app):
    return [{'path':p.relative_to(app).as_posix(),'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(app.rglob('*')) if p.is_file()]
def sources():
    patterns=['scripts/run-ios-e2e.py','scripts/run-ios-accessibility.py','scripts/ios_e2e_ui','scripts/ios_native_ui','scripts/ios_accessibility_ui','fixtures/user-scenarios','fixtures/portable-projects','fixtures/visual-export','examples/io-showcase.circ','examples/io-held-output.circ','examples/io-held-output.targets.json']
    paths=run(['git','-C',str(ROOT),'ls-files','--',*patterns]).splitlines()
    result={}
    for name in paths:
        data=(ROOT/name).read_bytes()
        assert data==subprocess.check_output(['git','-C',str(ROOT),'show',f'{SOURCE}:{name}']),name
        result[name]=hashlib.sha256(data).hexdigest()
    return result

def main():
    output=Path(sys.argv[1]).resolve()
    output.mkdir(parents=True,exist_ok=False)
    assert run(['git','-C',str(ROOT),'rev-parse','HEAD'])==SOURCE
    assert run(['git','-C',str(ROOT),'status','--porcelain'])==''
    assert run(['git','-C',str(PRODUCER),'rev-parse','HEAD'])==PRODUCER_SOURCE
    assert run(['git','-C',str(PRODUCER),'status','--porcelain'])==''
    assert sha(MANIFEST)==MANIFEST_SHA
    manifest=json.loads(MANIFEST.read_text())
    app=Path(manifest['artifact']['path'])
    expected=manifest['artifact']['files']
    assert inventory(app)==expected and len(expected)==12
    installed=Path(run(['xcrun','simctl','get_app_container',DEVICE,BUNDLE,'app']))
    assert inventory(installed)==expected
    spec=importlib.util.spec_from_file_location('artifact_support',ROOT/'scripts/run-ios-accessibility.py')
    common=importlib.util.module_from_spec(spec); spec.loader.exec_module(common)
    artifact=common.artifact(app,BUNDLE)
    assert artifact['bundle_tree_sha256']==manifest['artifact']['bundle_tree_sha256']=='813f1b2f05a28af4b593c8acf2c57d13257107ddb9ddcb9e38b35f2822a1d0ef'
    assert common.artifact(installed,BUNDLE)['bundle_tree_sha256']==artifact['bundle_tree_sha256']
    with (output/'codesign.txt').open('wb') as log:
        for bundle in (app,installed):
            subprocess.run(['codesign','--verify','--deep','--strict',str(bundle)],check=True,stdout=log,stderr=subprocess.STDOUT)
    catalog={}
    catalog_files={}
    for path in sorted((PRODUCER/'localization/messages').glob('*.json')):
        data=path.read_bytes()
        assert data==subprocess.check_output(['git','-C',str(PRODUCER),'show',f'{PRODUCER_SOURCE}:{path.relative_to(PRODUCER)}'])
        values=json.loads(data)
        assert not catalog.keys()&values.keys()
        catalog.update(values);catalog_files[str(path.relative_to(PRODUCER))]=hashlib.sha256(data).hexdigest()
    assert len(catalog)==2497
    assert all({'en','pt'} <= set(value) for value in catalog.values())
    for item in manifest['catalog']['files']:
        assert sha(Path(item['path']))==item['sha256']
    devices=json.loads(run(['xcrun','simctl','list','devices','available','-j']))['devices']
    device=next(dict(item,runtime=runtime) for runtime,items in devices.items() for item in items if item['udid']==DEVICE)
    assert device['state']=='Booted'
    voiceover=run(['xcrun','simctl','spawn',DEVICE,'defaults','read','com.apple.Accessibility','VoiceOverTouchEnabled'])
    assert voiceover=='0'
    subprocess.run(['xcrun','simctl','io',DEVICE,'screenshot',str(output/'framebuffer.png')],check=True,capture_output=True)
    import struct
    width,height=struct.unpack('>II',(output/'framebuffer.png').read_bytes()[16:24])
    assert width<height
    inputs=sources()
    target_names=re.findall(r'^\s+- ([A-Za-z0-9_]+\.swift)\s*$',(ROOT/'scripts/ios_e2e_ui/project.yml').read_text(),re.MULTILINE)
    assert len(target_names)==len(set(target_names))==17
    target={name:sha(ROOT/'scripts'/('ios_native_ui' if name in ('NativeUIHarness.swift','NativeTextReplacement.swift') else 'ios_e2e_ui')/name) for name in target_names}
    staged=dict(target)
    staged['AccessibilityUITests.swift']=sha(ROOT/'scripts/ios_accessibility_ui/AccessibilityUITests.swift')
    scenario=next(s for s in json.loads((ROOT/'fixtures/user-scenarios/editor-actions-v1.json').read_text())['scenarios'] if s['id']=='editing-connections-history-viewport')
    assert len(scenario['steps'])==62
    report={'status':'PASS','utc':datetime.now(timezone.utc).isoformat(),'harnessSource':SOURCE,'producerSource':PRODUCER_SOURCE,'manifestSHA256':MANIFEST_SHA,'artifact':artifact,'producerFiles':expected,'installedPath':str(installed),'catalogMessages':len(catalog),'catalogFiles':catalog_files,'device':device,'readerState':False,'voiceOverTouchEnabled':voiceover,'framebuffer':{'width':width,'height':height,'portrait':True},'selectedTest':SELECTOR,'testTimeoutSeconds':900,'contractSteps':62,'contractSHA256':sha(ROOT/'fixtures/user-scenarios/editor-actions-v1.json'),'compiledSources':target,'compiledCount':len(target),'stagedSources':staged,'stagedCount':len(staged),'inputs':inputs}
    if len(sys.argv)>2:
        before=json.loads(Path(sys.argv[2]).read_text())
        for key in ('harnessSource','producerSource','manifestSHA256','artifact','producerFiles','catalogMessages','catalogFiles','readerState','voiceOverTouchEnabled','selectedTest','testTimeoutSeconds','contractSteps','contractSHA256','compiledSources','stagedSources','inputs'):
            assert report[key]==before[key],key
        report['prePostInputsIdentical']=True
    (output/'preflight.json').write_text(json.dumps(report,indent=2)+'\n')
    (output/'producer-artifact.json').write_bytes(MANIFEST.read_bytes())
    print(json.dumps({key:report[key] for key in ('status','harnessSource','compiledCount','stagedCount','catalogMessages','readerState','framebuffer')}))
if __name__=='__main__':main()
