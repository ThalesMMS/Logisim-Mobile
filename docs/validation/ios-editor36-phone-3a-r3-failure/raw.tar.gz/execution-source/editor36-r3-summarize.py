"""Summarize exported Editor36 R3 evidence without driving the Simulator."""
from pathlib import Path
import hashlib,json,re,sys
root=Path(__file__).resolve().parents[1]
output=root/'outputs/ios-editor36-phone-3a-003'
report=json.loads((output/'results.json').read_text())
assert report['native_execution_gate'] in ('NATIVE_PASS','NATIVE_FAIL')
contract=json.loads((output/'harness/editor-actions-v1.json').read_text())
steps=contract['scenarios'][0]['steps']
log=(output/'test.log').read_text(errors='strict')
groups=json.loads((output/'attachments/manifest.json').read_text())
attachments=[a for group in groups for a in group.get('attachments',[])]
def sha(data):return hashlib.sha256(data).hexdigest()
notes=[]; exports=[]; observed=[];decisions=[]
for item in attachments:
 name=item['exportedFileName'];title=item['suggestedHumanReadableName'];path=output/'attachments'/name
 if found:=re.match(r'contract-step-(\d+)_',title):
  n=int(found[1]);raw=path.read_bytes();assert f'step={n}, action={steps[n-1]["action"]},'.encode() in raw and raw.endswith(b'status=passed')
  notes.append({'step':n,'attachment':name,'bytes':len(raw),'sha256':sha(raw)})
 if found:=re.match(r'observed-editor-export-(\d+)_',title):
  raw=path.read_bytes();exports.append({'exportIndex':int(found[1]),'attachment':name,'bytes':len(raw),'sha256':sha(raw)})
 if title.startswith(('editor-header-observation_','editor-header-decision_')):
  raw=path.read_text();fields=dict(re.findall(r'(?:^|;\s*)([A-Za-z]+)=((?:(?!;\s*[A-Za-z]+=).)*)',raw))
  record={'attachment':name,'timestamp':item.get('timestamp'),'payload':raw,'fields':fields}
  (observed if title.startswith('editor-header-observation_') else decisions).append(record)
notes.sort(key=lambda x:x['step']);exports.sort(key=lambda x:x['exportIndex'])
assert [n['step'] for n in notes]==list(range(1,len(notes)+1))
checkpoints=[(i+1,s['checkpoint']) for i,s in enumerate(steps) if s['action']=='assertDocument']
assert len(exports)<=len(checkpoints)
for item,(step,checkpoint) in zip(exports,checkpoints):item.update(contractStep=step,checkpoint=checkpoint)
seen=re.findall(r'(?m)^\s+t =\s+[0-9.]+s contract step (\d+): (\w+)$',log)
assert seen==[(str(i),steps[i-1]['action']) for i in range(1,len(seen)+1)]
terminal=re.findall(r"Test Case '-\[EditorEndToEndTests\.EditorEndToEndTests testEditingConnectionsHistoryAndViewport\]' (passed|failed) \(([0-9.]+) seconds\)\.",log)
summary={'status':report['execution']['status'],'gate':report['native_execution_gate'],'runId':report['run_id'],'started':report['started'],'finished':report['finished'],'selectedTests':report['selected_tests'],'caseTerminal':terminal,'passedSteps':len(notes),'attemptedSteps':len(seen),'lastAttemptedStep':seen[-1] if seen else None,'notes':notes,'exports':exports,'attachmentCount':len(attachments),'headerObservations':len(observed),'headerDecisions':len(decisions),'decisionsByType':{decision:sum(r['fields'].get('decision')==decision for r in decisions) for decision in sorted({r['fields'].get('decision','UNKNOWN') for r in decisions})},'selectedCounts':{value:sum(r['fields'].get('selected')==value for r in observed) for value in ('true','false','unobserved')},'failureLines':[line for line in log.splitlines() if 'error:' in line or 'failed (' in line or 'Executed ' in line]}
(output/'evidence-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(output/'header-evidence.json').write_text(json.dumps({'observations':sorted(observed,key=lambda r:(r['fields'].get('invocation',''),int(r['fields'].get('order','-1')))),'decisions':sorted(decisions,key=lambda r:(r.get('timestamp') or -1,r['attachment']))},indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ('notes','exports','failureLines')},indent=2))
print('\n'.join(summary['failureLines']))
