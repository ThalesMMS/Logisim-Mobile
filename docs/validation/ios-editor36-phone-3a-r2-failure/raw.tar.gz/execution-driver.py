"""Serialize only XCTest compilation; reserve the explicit device for one native case."""
import importlib.util
from pathlib import Path
import sys

root = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("selected_editor_runner", root / "scripts/run-ios-e2e.py")
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)
original_support = runner.support


def support():
    common = original_support()
    original_run = common.run

    def run(command, **kwargs):
        if command[0] == "xcodebuild" and "build-for-testing" in command:
            command = [sys.executable, "/tmp/logisim-gradle-serial.py", *command]
        return original_run(command, **kwargs)

    common.run = run
    return common


runner.support = support
raise SystemExit(runner.main())
