"""Run one pinned Editor62 selection; serialize only XCTest compilation."""
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys

root=Path(__file__).resolve().parents[1]
preflight=json.loads((root/'outputs/ios-editor36-phone-3a-preflight-004/preflight.json').read_text())
spec=importlib.util.spec_from_file_location('selected_editor_runner',root/'scripts/run-ios-e2e.py')
runner=importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)
original_support=runner.support

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def support():
    common=original_support()
    original_run=common.run
    def run(command,**kwargs):
        if command[0]=='xcodebuild' and 'build-for-testing' in command:
            project=Path(command[command.index('-project')+1]).parent
            staged={p.name:sha(p) for p in sorted(project.glob('*.swift'))}
            assert staged==preflight['stagedSources'] and len(staged)==18
            names=re.findall(r'^\s+- ([A-Za-z0-9_]+\.swift)\s*$',(project/'project.yml').read_text(),re.MULTILINE)
            compiled={name:sha(project/name) for name in names}
            assert compiled==preflight['compiledSources'] and len(compiled)==17
            assert sha(project/'editor-actions-v1.json')==preflight['contractSHA256']
            catalog=json.loads((project/'Catalog.json').read_text())
            assert len(catalog)==2497
            pin={'status':'PASS','harnessSource':preflight['harnessSource'],'stagedCount':len(staged),'compiledCount':len(compiled),'excludedStagedSources':sorted(set(staged)-set(compiled)),'stagedSources':staged,'compiledSources':compiled,'contractSHA256':sha(project/'editor-actions-v1.json'),'catalogSHA256':sha(project/'Catalog.json'),'catalogMessages':len(catalog)}
            (project.parent/'staged-compiled-pin.json').write_text(json.dumps(pin,indent=2)+'\n')
            command=[sys.executable,'/tmp/logisim-gradle-serial.py',*command]
        if command[0]=='xcodebuild' and 'test-without-building' in command:
            expected=f"-only-testing:{preflight['selectedTest']}"
            assert [item for item in command if item.startswith('-only-testing:')]==[expected]
            assert command[command.index('-default-test-execution-time-allowance')+1]=='900'
        return original_run(command,**kwargs)
    common.run=run
    return common
runner.support=support
raise SystemExit(runner.main())
