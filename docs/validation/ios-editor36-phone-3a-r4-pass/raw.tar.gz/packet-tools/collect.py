#!/usr/bin/env python3
"""Draft an Editor36 evidence inventory after terminal/postflight confirmation.

This program never runs an app, build, simulator command or Git operation.
It inventories originals; it does not create a final evidence package.
"""
from collections import Counter, defaultdict
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path, PurePosixPath
import re
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
CONTRACT_SHA = "9a77ddc4628e87a87b3dbcbe28a46691ed15b10f22b94b70544cce9944216ec9"
SELECTOR = "EditorEndToEndTests/EditorEndToEndTests/testEditingConnectionsHistoryAndViewport"
APP_SOURCE = "3a0a01f1af05dd3fea75d5a1499c762d039c478a"
APP_BUNDLE = "813f1b2f05a28af4b593c8acf2c57d13257107ddb9ddcb9e38b35f2822a1d0ef"
spec = importlib.util.spec_from_file_location("editor36_inventory_oracle", ROOT / "oracle.py")
oracle = importlib.util.module_from_spec(spec)
spec.loader.exec_module(oracle)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def record(data):
    return {"bytes": len(data), "sha256": sha(data)}


def safe_name(name):
    p = PurePosixPath(name)
    if not name or p.is_absolute() or ".." in p.parts or p.as_posix() != name:
        raise ValueError("Unsafe relative evidence path")
    return name


def require(condition, message):
    if not condition:
        raise ValueError(message)


def fields(payload):
    pairs = re.findall(r"(?:^|; )([A-Za-z][A-Za-z0-9]*)=(.*?)(?=; [A-Za-z][A-Za-z0-9]*=|$)", payload)
    require(len(pairs) == len({k for k, _ in pairs}), "Duplicate header field")
    return dict(pairs)


def summarize(native, pre, post, expected_source, expected_run):
    """Pure inventory/oracle over bytes; callers must confirm terminal first."""
    contract_raw = native["harness/editor-actions-v1.json"]
    require(sha(contract_raw) == CONTRACT_SHA, "Contract byte identity changed")
    contract = json.loads(contract_raw)
    scenario = next(s for s in contract["scenarios"] if s["id"] == "editing-connections-history-viewport")
    steps = scenario["steps"]
    require(len(steps) == 62, "Expected the unchanged 62-step contract")
    require(pre["status"] == post["status"] == "PASS" and post["prePostInputsIdentical"] is True,
            "Successful pre/postflight required")
    require(pre["inputs"] == post["inputs"], "Pre/post source input maps differ")
    for item in (pre, post):
        require(item["harnessSource"] == expected_source and item["producerSource"] == APP_SOURCE,
                "Source identity mismatch")
        require(item["selectedTest"] == SELECTOR and item["testTimeoutSeconds"] == 900 and
                item["contractSHA256"] == CONTRACT_SHA and item["contractSteps"] == 62,
                "Pre/post selected contract mismatch")
        require(item["artifact"]["bundle_tree_sha256"] == APP_BUNDLE, "App identity mismatch")
        require(item["compiledCount"] == len(item["compiledSources"]) and
                item["stagedCount"] == len(item["stagedSources"]), "Source count mismatch")
    require(pre["compiledSources"] == post["compiledSources"] and
            pre["stagedSources"] == post["stagedSources"], "Pre/post target source maps differ")
    result = json.loads(native["results.json"])
    require(bool(result.get("finished")), "No finished Native result")
    require(result["run_id"] == expected_run and result["selected_tests"] == [SELECTOR] and
            result["execution"]["selection"] == [SELECTOR], "Wrong run or selection")
    require(result["alpha"] is False and result["test_timeout_seconds"] == 900,
            "Alpha or timeout changed")
    native_status = result["execution"]["status"]
    require(native_status in {"PASS", "FAIL"}, "Native execution is not terminal")
    require(result["native_execution_gate"] == "NATIVE_" + native_status and
            result["execution"]["exit_code"] == (0 if native_status == "PASS" else 65),
            "Conflicting Native terminal fields")
    require(result["declared_baseline_sha"] == APP_SOURCE and
            result["artifact"]["bundle_tree_sha256"] == APP_BUNDLE, "Native app identity mismatch")
    device_identity = lambda item: tuple(item[key] for key in ("udid", "runtime", "deviceTypeIdentifier", "state"))
    require(device_identity(result["device"]) == device_identity(pre["device"]) == device_identity(post["device"]) and
            result["simulator"] == pre["device"]["udid"] and result["physical_device"] is False,
            "Native/pre/post device mismatch")
    run = json.loads(native["harness/Run.json"])
    require(run["run_id"] == expected_run and run["simulatorUDID"] == result["simulator"],
            "Prepared run mismatch")
    prepared = {PurePosixPath(name).name: sha(data) for name, data in native.items()
                if name.startswith("harness/") and name.count("/") == 1 and name.endswith(".swift")}
    targets = re.findall(r"^\s+- ([A-Za-z0-9_]+\.swift)\s*$", native["harness/project.yml"].decode(), re.M)
    require(len(targets) == len(set(targets)), "Duplicate target source")
    require(prepared == pre["stagedSources"] == result["harness_sources"], "Prepared source byte mismatch")
    require({name: prepared[name] for name in targets} == pre["compiledSources"], "Compiled source mismatch")
    log = native["test.log"].decode()
    terminal = re.findall(r"Test Case .*testEditingConnectionsHistoryAndViewport.* (passed|failed) \(([0-9.]+) seconds\)\.", log)
    require(len(terminal) == 1 and terminal[0][0] == ("passed" if native_status == "PASS" else "failed"),
            "Missing or conflicting selected-test terminal log")
    counts = re.findall(r"Executed (\d+) test, with (\d+) failure", log)
    require(counts and all(x == ("1", "0" if native_status == "PASS" else "1") for x in counts),
            "Missing or conflicting Native test summary")
    starts = re.findall(r"(?m)^\s+t =\s+[0-9.]+s contract step (\d+): (\w+)$", log)
    require(1 <= len(starts) <= len(steps) and starts ==
            [(str(i), steps[i - 1]["action"]) for i in range(1, len(starts) + 1)], "Contract starts are not a prefix")
    attachments = [a for group in json.loads(native["attachments/manifest.json"])
                   for a in group.get("attachments", [])]
    require(len({a["exportedFileName"] for a in attachments}) == len(attachments), "Duplicate attachment path")
    metadata = {a["exportedFileName"]: a for a in attachments}
    notes, exports, headers = [], [], []
    for a in attachments:
        name, title = safe_name(a["exportedFileName"]), a["suggestedHumanReadableName"]
        require(a["deviceId"] == result["simulator"], "Attachment device mismatch")
        if name.lower().endswith((".mp4", ".mov")):
            continue
        raw = native["attachments/" + name]
        if match := re.match(r"contract-step-(\d+)_", title):
            notes.append((int(match[1]), name, raw))
        if match := re.match(r"observed-editor-export-(\d+)_", title):
            exports.append((int(match[1]), name, raw))
        if title.startswith(("editor-header-observation_", "editor-header-decision_")):
            headers.append({"attachment": name, "timestamp": a["timestamp"], "payload": raw.decode(),
                            "kind": "observation" if title.startswith("editor-header-observation_") else "decision",
                            "fields": fields(raw.decode())})
    notes.sort()
    note_times = [metadata[name]["timestamp"] for _, name, _ in notes]
    require(note_times == sorted(note_times), "Step-note order conflicts with timestamps")
    completed = oracle.check_step_notes([(n, raw) for n, _, raw in notes], steps, native_status == "PASS")
    require(completed <= len(starts) <= completed + 1, "Completed notes conflict with attempted steps")
    require([n for n, _, _ in exports] == list(range(1, len(exports) + 1)) or
            [n for n, _, _ in sorted(exports)] == list(range(1, len(exports) + 1)), "Nonsequential exports")
    exports.sort()
    export_times = [metadata[name]["timestamp"] for _, name, _ in exports]
    require(export_times == sorted(export_times), "Export order conflicts with timestamps")
    checkpoint_calls = [(i, step["checkpoint"]) for i, step in enumerate(steps[:len(starts)], 1)
                        if step["action"] == "assertDocument"]
    completed_exports = sum(step["action"] == "assertDocument" for step in steps[:completed])
    require(completed_exports <= len(exports) <= len(checkpoint_calls), "Exports conflict with checkpoint calls")
    checked, history, errors = [], [], []
    for (number, name, raw), (step, checkpoint) in zip(exports, checkpoint_calls):
        item = {"exportIndex": number, "contractStep": step, "checkpoint": checkpoint,
                "attachment": name, "timestamp": metadata[name]["timestamp"], **record(raw)}
        try:
            _, identities = oracle.check_xml(raw, contract["snapshots"][checkpoint], checkpoint)
            history.append((checkpoint, identities))
            item["oracleStatus"] = "PASS"
        except (AssertionError, ValueError, KeyError, AttributeError, ET.ParseError) as error:
            item["oracleStatus"], item["oracleError"] = "FAIL", str(error)
            errors.append({"exportIndex": number, "error": str(error)})
        checked.append(item)
    try:
        oracle.check_identity_history(history)
    except (AssertionError, ValueError, KeyError) as error:
        errors.append({"identityHistory": str(error)})
    groups = defaultdict(list)
    for item in headers:
        require(bool(item["fields"].get("invocation")), "Missing header invocation")
        groups[item["fields"]["invocation"]].append(item)
    for rows in groups.values():
        observations = sorted((r for r in rows if r["kind"] == "observation"), key=lambda r: int(r["fields"]["order"]))
        require([int(r["fields"]["order"]) for r in observations] == list(range(len(observations))),
                "Header observations have duplicate or missing order")
        require([r["timestamp"] for r in observations] == sorted(r["timestamp"] for r in observations),
                "Header order conflicts with timestamps")
        rows.sort(key=lambda r: (r["timestamp"], r["attachment"]))
    return {"collectionStatus": "DRAFT_INVENTORY", "qualification": "Independent terminal/package review required",
            "runId": expected_run, "harnessSource": expected_source, "nativeStatus": native_status,
            "caseSeconds": float(terminal[0][1]), "nativeExitCode": result["execution"]["exit_code"],
            "compiledCount": len(targets), "preparedCount": len(prepared), "completedSteps": completed,
            "startedSteps": len(starts), "stepNotes": [{"step": n, "attachment": name,
                "timestamp": metadata[name]["timestamp"]} for n, name, _ in notes],
            "exports": checked, "oracleErrors": errors, "headerByInvocation": dict(groups),
            "headerObservationCount": sum(r["kind"] == "observation" for r in headers),
            "headerDecisionCounts": dict(Counter(r["fields"].get("decision", "<missing>") for r in headers if r["kind"] == "decision")),
            "headerSelectedStates": dict(Counter(r["fields"].get("selected", "<missing>") for r in headers if r["kind"] == "observation")),
            "headerHittableStates": dict(Counter(r["fields"].get("hittable", "<missing>") for r in headers if r["kind"] == "observation")),
            "limits": ["Header state/request records do not prove callback delivery.",
                       "Unobserved/unqueried values are preserved as strings, not coerced to false.",
                       "Additional output/copy/zoom oracles must be reviewed if those steps were reached."]}


def tree_inventory(path, excluded_roots=()):
    require(not path.is_symlink(), "Symlink evidence root")
    result = {}
    for directory, directories, filenames in os.walk(path, followlinks=False):
        base = Path(directory)
        if base == path:
            directories[:] = [name for name in directories if name not in excluded_roots]
        for name in directories + filenames:
            require(not (base / name).is_symlink(), "Symlink evidence entry")
        for name in filenames:
            entry = base / name
            require(entry.is_file(), "Non-regular evidence entry")
            result[safe_name(entry.relative_to(path).as_posix())] = record(entry.read_bytes())
    return result


def private_value_scan(payloads):
    values = [value.encode() for key, value in os.environ.items()
              if re.search(r"TOKEN|SECRET|PASSWORD|API_KEY", key, re.I) and len(value) >= 12]
    require(not any(value in data for data in payloads for value in values),
            "Credential-like environment value found; collection refused without printing it")


def collect(native_path, pre_path, post_path, expected_source, expected_run, terminal_confirmed=False):
    require(terminal_confirmed, "Execution owner must confirm terminal and completed postflight before collection")
    # Postflight is read before opening Native results. No polling or live-state inference.
    pre_bytes = (pre_path / "preflight.json").read_bytes()
    post_bytes = (post_path / "preflight.json").read_bytes()
    pre, post = json.loads(pre_bytes), json.loads(post_bytes)
    require(post["status"] == "PASS" and post["prePostInputsIdentical"] is True, "Postflight is not complete")
    before = {"native": tree_inventory(native_path, {"DerivedData"}),
              "preflight": tree_inventory(pre_path), "postflight": tree_inventory(post_path)}
    require(record(pre_bytes) == before["preflight"]["preflight.json"] and
            record(post_bytes) == before["postflight"]["preflight.json"],
            "Parsed pre/post bytes differ from inventory snapshot")
    native = {name: (native_path / name).read_bytes() for name in before["native"]
              if not name.startswith("editor.xcresult/") and name not in {"simulator.log", "last-screen.png"}
              and not name.lower().endswith((".mp4", ".mov"))}
    require(all(record(data) == before["native"][name] for name, data in native.items()),
            "Parsed Native bytes differ from inventory snapshot")
    result = summarize(native, pre, post, expected_source, expected_run)
    private_value_scan([*native.values(),
        *(path.read_bytes() for root in (pre_path, post_path) for path in root.rglob("*") if path.is_file())])
    result["fileInventories"] = before
    result["archiveCandidates"] = sorted(native)
    result["excludedTrees"] = [{"relativePath": "DerivedData", "reason": "Build intermediates are not evidence candidates."}]
    result["localOnly"] = [{"relativePath": name, **value} for name, value in before["native"].items()
                           if name not in native and not name.startswith("editor.xcresult/")]
    xcresult = {name.removeprefix("editor.xcresult/"): value for name, value in before["native"].items()
                if name.startswith("editor.xcresult/")}
    if xcresult:
        digest = hashlib.sha256()
        for name, value in sorted(xcresult.items(), key=lambda item: PurePosixPath(item[0]).parts):
            digest.update((name + "\0" + value["sha256"] + "\n").encode())
        result["localOnly"].append({"relativePath": "editor.xcresult", "fileCount": len(xcresult),
            "bytes": sum(value["bytes"] for value in xcresult.values()), "sha256": digest.hexdigest(),
            "algorithm": "Sorted pathlib path parts; relative POSIX path + NUL + file SHA256 hex + newline."})
    after = {"native": tree_inventory(native_path, {"DerivedData"}),
             "preflight": tree_inventory(pre_path), "postflight": tree_inventory(post_path)}
    require(before == after, "Evidence files changed during collection")
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--terminal-confirmed", action="store_true", required=True)
    parser.add_argument("--native-output", type=Path, required=True)
    parser.add_argument("--preflight", type=Path, required=True)
    parser.add_argument("--postflight", type=Path, required=True)
    parser.add_argument("--harness-source", required=True)
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--output", type=Path, required=True, help="A new draft JSON path; existing files are refused")
    args = parser.parse_args()
    require(not args.output.exists(), "Draft destination already exists")
    require(not any(args.output.resolve().is_relative_to(root.resolve())
                    for root in (args.native_output, args.preflight, args.postflight)),
            "Draft destination must be outside the immutable evidence inputs")
    summary = collect(args.native_output, args.preflight, args.postflight, args.harness_source,
                      args.run_id, args.terminal_confirmed)
    with args.output.open("x") as target:
        json.dump(summary, target, indent=2)
        target.write("\n")
    print(json.dumps({"collectionStatus": summary["collectionStatus"], "nativeStatus": summary["nativeStatus"],
                      "completedSteps": summary["completedSteps"], "xmlExports": len(summary["exports"])}))
