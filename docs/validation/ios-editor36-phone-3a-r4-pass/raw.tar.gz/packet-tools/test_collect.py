"""Offline rehearsal using the committed R3 archive, never the active R4 output."""
import copy
import importlib.util
import json
from pathlib import Path
import tarfile
import tempfile
import unittest
from unittest import mock
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("editor36_packet_collect", ROOT / "collect.py")
collect = importlib.util.module_from_spec(spec)
spec.loader.exec_module(collect)


class InventoryChecks(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        archive = ROOT.parent.parent / "docs/validation/ios-editor36-phone-3a-r3-failure/raw.tar.gz"
        with tarfile.open(archive) as raw:
            cls.native = {item.name: raw.extractfile(item).read() for item in raw if item.isfile()}
        cls.pre = json.loads(cls.native["preflight/preflight.json"])
        cls.post = json.loads(cls.native["postflight/preflight.json"])
        cls.source = cls.pre["harnessSource"]
        cls.expected_run = json.loads(cls.native["results.json"])["run_id"]

    def summarize(self, native=None, pre=None, post=None):
        return collect.summarize(native if native is not None else self.native,
                                 pre if pre is not None else self.pre,
                                 post if post is not None else self.post, self.source, self.expected_run)

    def test_r3_rehearsal_derives_observed_counts_and_checkpoint_steps(self):
        result = self.summarize()
        self.assertEqual(("DRAFT_INVENTORY", "FAIL", 15, 16, 17, 18),
                         tuple(result[k] for k in ("collectionStatus", "nativeStatus", "completedSteps",
                                                 "startedSteps", "compiledCount", "preparedCount")))
        self.assertEqual([2, 7, 9, 11, 13, 15], [row["contractStep"] for row in result["exports"]])
        self.assertFalse(result["oracleErrors"])

    def test_owner_terminal_confirmation_is_required_before_any_path_read(self):
        with self.assertRaisesRegex(ValueError, "Execution owner"):
            collect.collect(Path("/does/not/exist"), Path("/does/not/exist"), Path("/does/not/exist"),
                            "unused", "unused", terminal_confirmed=False)

    def test_unfinished_result_is_not_a_terminal_inventory(self):
        native = dict(self.native)
        result = json.loads(native["results.json"])
        result.pop("finished")
        native["results.json"] = json.dumps(result).encode()
        with self.assertRaisesRegex(ValueError, "finished"):
            self.summarize(native=native)

    def test_postflight_input_drift_is_rejected(self):
        post = copy.deepcopy(self.post)
        post["inputs"][next(iter(post["inputs"]))] = "0" * 64
        with self.assertRaisesRegex(ValueError, "input maps differ"):
            self.summarize(post=post)

    def test_invalid_xml_is_preserved_as_oracle_failure_without_relabelling_native(self):
        native = dict(self.native)
        exported = self.summarize()["exports"][1]["attachment"]
        document = ET.fromstring(native["attachments/" + exported])
        ET.SubElement(document.find("circuit"), "wire", {"from": "(100,100)", "to": "(170,100)"})
        native["attachments/" + exported] = ET.tostring(document)
        result = self.summarize(native=native)
        self.assertEqual("FAIL", result["nativeStatus"])
        self.assertEqual("FAIL", result["exports"][1]["oracleStatus"])
        self.assertTrue(result["oracleErrors"])

    def test_unknown_header_states_remain_literal(self):
        result = self.summarize()
        self.assertEqual({"true": 7, "unobserved": 13}, result["headerSelectedStates"])
        self.assertEqual({"true": 19, "unqueried": 1}, result["headerHittableStates"])
        self.assertEqual({"skip-publicly-selected": 7}, result["headerDecisionCounts"])

    def test_missing_xml_main_is_reported_without_losing_the_native_inventory(self):
        native = dict(self.native)
        exported = self.summarize()["exports"][1]["attachment"]
        document = ET.fromstring(native["attachments/" + exported])
        document.remove(document.find("main"))
        native["attachments/" + exported] = ET.tostring(document)
        result = self.summarize(native=native)
        self.assertEqual("FAIL", result["nativeStatus"])
        self.assertEqual("FAIL", result["exports"][1]["oracleStatus"])
        self.assertTrue(result["oracleErrors"])

    def test_missing_step_note_is_not_silently_renumbered(self):
        native = dict(self.native)
        manifest = json.loads(native["attachments/manifest.json"])
        for group in manifest:
            group["attachments"] = [a for a in group.get("attachments", [])
                                    if not a["suggestedHumanReadableName"].startswith("contract-step-9_")]
        native["attachments/manifest.json"] = json.dumps(manifest).encode()
        with self.assertRaises(AssertionError):
            self.summarize(native=native)

    def test_compiled_target_must_match_prepared_source_hashes(self):
        native = dict(self.native)
        native["harness/EditorEndToEndTests.swift"] += b"\n// drift\n"
        with self.assertRaisesRegex(ValueError, "Prepared source byte"):
            self.summarize(native=native)

    def test_pre_post_change_between_parse_and_inventory_is_rejected(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            native, pre, post = [root / name for name in ("native", "pre", "post")]
            for directory in (native, pre, post):
                directory.mkdir()
            (pre / "preflight.json").write_text(json.dumps(self.pre))
            (post / "preflight.json").write_text(json.dumps(self.post))
            original = collect.tree_inventory

            def change_after_parse(path, excluded_roots=()):
                if path == native:
                    changed = dict(self.post, status="FAIL")
                    (post / "preflight.json").write_text(json.dumps(changed))
                return original(path, excluded_roots)

            with mock.patch.object(collect, "tree_inventory", side_effect=change_after_parse):
                with self.assertRaisesRegex(ValueError, "Parsed pre/post bytes"):
                    collect.collect(native, pre, post, self.source, self.expected_run, terminal_confirmed=True)

    def test_derived_data_is_not_read_or_included_as_evidence(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "DerivedData").mkdir()
            (root / "DerivedData" / "intermediate.bin").write_bytes(b"excluded")
            (root / "test.log").write_bytes(b"preserved")
            self.assertEqual({"test.log": collect.record(b"preserved")},
                             collect.tree_inventory(root, {"DerivedData"}))


if __name__ == "__main__":
    unittest.main()
