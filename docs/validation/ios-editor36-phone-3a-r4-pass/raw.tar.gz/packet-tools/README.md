# Editor36 terminal inventory tools

Prepared offline from the committed R3 evidence package (79365b4e). No R4 result, active output, device or app was read to prepare these tools. The R4 execution owner must explicitly confirm termination and successful postflight before collection. This directory is a draft toolset, not a final R4 evidence package or a Native qualification.

The expected R4 identities supplied by the execution owner are harness source `f25facb3f53a166c375cf2379b0e49839ecec022` and run ID `0a10c9841e58`. `tool-inputs.json` records those expectations and the unchanged contract/oracle hashes; it contains no observed R4 result.

After the owner supplies terminal and pre/postflight locations, run `collect.py --terminal-confirmed --native-output PATH --preflight PATH --postflight PATH --harness-source SHA --run-id ID --output NEW_DRAFT_JSON`. Existing destinations and destinations inside the source evidence directories are refused. The tool requires a finished, internally consistent selected-test terminal and completed postflight. It performs no polling, build, app launch, simulator operation, Git operation or mutation of originals.

The draft inventory derives completed notes and attempted steps from the literal 62-step contract and the full test log. It maps export indices to the sequence of `assertDocument` calls, including an XML already emitted by an assertion that subsequently failed. XML and identity oracles preserve any failure as an error record without changing the Native result. Header records retain raw payloads, timestamp, invocation, order and phase; `unobserved` and `unqueried` remain strings. Decision counts are derived rather than copied from R3.

Evidence files receive size/SHA256 records before and after collection; any drift aborts. The bytes used to parse Native/pre/post records must also match that inventory snapshot. DerivedData is excluded without reading its contents. Non-video Native/harness/attachment files become archive candidates. Video, Simulator log, xcresult and post-teardown screenshot remain local references. The xcresult tree digest uses sorted path parts and relative POSIX path + NUL + file SHA256 hex + newline. Current credential-like environment values are checked against candidate bytes without printing their values. Pre/postflight files are inventoried separately. No final tar or receipt is created.

Before publishing a final packet:

1. Confirm the selected test, timeout 900, alpha disabled, device lease return, frozen app/manifest/catalogue and source identity against the owner's terminal record.
2. Preserve all attachments except local-only media, full manifests/logs, harness/resources, original pinned source inputs, driver and pre/postflight scripts. Include setup diagnostics with Native count zero separately when present.
3. Review every reached output/copy/zoom assertion and its independent oracle. A complete inventory and passed XML checks alone do not qualify a Native PASS.
4. Build a new archive with safe paths, no links or duplicate names, per-member size/SHA256 and screenshot-appropriate bounds. Preserve original raw logs in full.
5. Add local-only path/size/hash references, a complete publication hash map, negative tests that rebuild checksum layers, independent review and a replay without Git or local recordings.

The eleven rehearsal checks use only R3's committed archive and temporary synthetic files: `PYTHONDONTWRITEBYTECODE=1 python3 test_collect.py`. They exercise incomplete-result/postflight refusal, contract mapping, source drift, XML failure reporting, literal unknown telemetry states, snapshot drift and DerivedData exclusion. R3 counts in these tests are fixtures, not R4 expectations.
