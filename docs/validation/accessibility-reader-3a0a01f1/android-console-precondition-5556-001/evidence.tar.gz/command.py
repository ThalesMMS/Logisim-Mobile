from pathlib import Path
import datetime,json,subprocess,sys,time
out=Path(__file__).resolve().parent
name=sys.argv[1];args=sys.argv[2:]
cmd=['/Users/thales/Library/Android/sdk/platform-tools/adb','-s','emulator-5556',*args]
t=time.monotonic();r=subprocess.run(cmd,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=15)
(out/(name+'.stdout.bin')).write_bytes(r.stdout);(out/(name+'.stderr.txt')).write_bytes(r.stderr)
rec={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'argv':cmd,'exit':r.returncode,'seconds':round(time.monotonic()-t,3)}
(out/(name+'.json')).write_text(json.dumps(rec,indent=2)+'\n')
print(json.dumps(rec));raise SystemExit(r.returncode)
