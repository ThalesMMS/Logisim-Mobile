from pathlib import Path
import datetime,json,subprocess,sys,time
out=Path(__file__).resolve().parent
name=sys.argv[1];args=sys.argv[2:];cmd=['/Users/thales/Library/Android/sdk/platform-tools/adb','-s','emulator-5556',*args]
start=time.monotonic();r=subprocess.run(cmd,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30)
(out/(name+'.stdout.bin')).write_bytes(r.stdout);(out/(name+'.stderr.txt')).write_text(r.stderr.decode(errors='replace'))
rec={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':cmd,'exit_code':r.returncode,'duration_seconds':round(time.monotonic()-start,3)}
(out/(name+'.json')).write_text(json.dumps(rec,indent=2)+'\n')
if args[:2]==['exec-out','screencap']:(out/(name+'.png')).write_bytes(r.stdout)
else:print(r.stdout.decode(errors='replace'))
print(json.dumps(rec));raise SystemExit(r.returncode)
