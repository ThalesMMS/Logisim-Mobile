from pathlib import Path
import contextlib,io,json,os,socket,subprocess,sys,unittest
from unittest.mock import patch
root=Path(__file__).resolve().parents[2]
source=root/'docs/validation/accessibility-reader-3a0a01f1/android-console-one-gesture-prepared-001'
sys.path[:0]=[str(source),str(source/'checker')]
attempts=[]
def blocked(*args,**kwargs):
    attempts.append('external-process-or-socket')
    raise AssertionError('Only fake transports are permitted')
log=io.StringIO()
with contextlib.ExitStack() as stack:
    for owner,name in [(subprocess,'Popen'),(subprocess,'run'),(subprocess,'call'),(subprocess,'check_call'),(subprocess,'check_output'),(os,'system'),(socket,'socket')]:
        stack.enter_context(patch.object(owner,name,blocked))
    suite=unittest.defaultTestLoader.loadTestsFromNames(['contact_test','test_run_contact','test_check_binding','test_check_typeb_trace','test_review_regressions'])
    with contextlib.redirect_stdout(log),contextlib.redirect_stderr(log):
        result=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
receipt={'scope':'Combined pure offline/fake tests; no ADB, kernel monitor, reader or controller RPC','tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skips':len(result.skipped),'external_attempts':attempts,'runtime':'NOT_RUN'}
out=Path(__file__).resolve().parent
(out/'combined-offline.log').write_text(log.getvalue())
(out/'combined-offline.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
raise SystemExit(0 if result.wasSuccessful() and not attempts else 1)
